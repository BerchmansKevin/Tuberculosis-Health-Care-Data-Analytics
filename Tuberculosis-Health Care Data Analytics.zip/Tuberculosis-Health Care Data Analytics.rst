HEALTHCARE DATA ANALYTICS
-------------------------

``Topic : TB (Tuberculosis)``
-----------------------------

.. code:: ipython3

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    %matplotlib inline
    import seaborn as sns

.. code:: ipython3

    tb = pd.read_csv("Tb disease symptoms.csv")

.. code:: ipython3

    tb




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>995</th>
          <td>996</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>996</th>
          <td>997</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>997</th>
          <td>998</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>998</th>
          <td>999</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>999</th>
          <td>1000</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>1000 rows × 14 columns</p>
    </div>



.. code:: ipython3

    tb.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    tb.tail()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>995</th>
          <td>996</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>996</th>
          <td>997</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>997</th>
          <td>998</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>998</th>
          <td>999</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>999</th>
          <td>1000</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    tb.shape




.. parsed-literal::

    (1000, 14)



.. code:: ipython3

    tb.size




.. parsed-literal::

    14000



.. code:: ipython3

    tb.dtypes




.. parsed-literal::

    no                                                           int64
    fever_for_two_weeks                                          int64
    coughing_blood                                               int64
    sputum_mixed with blood                                      int64
    night_sweats                                                 int64
    chest_pain                                                   int64
    backpain_in_certain_parts                                    int64
    shortness_of_breath                                          int64
    weight_loss                                                  int64
    body feels tired                                             int64
    lumps_appear_around_the_armpits_and_neck                     int64
    cough_and_phlegm_continuously_for_two_weeks_to_four_weeks    int64
    swollen_lymph_nodes                                          int64
    loss_of_appetite                                             int64
    dtype: object



.. code:: ipython3

    type(tb)




.. parsed-literal::

    pandas.core.frame.DataFrame



.. code:: ipython3

    tb.isnull().head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
        </tr>
        <tr>
          <th>1</th>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
        </tr>
        <tr>
          <th>2</th>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
        </tr>
        <tr>
          <th>3</th>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
        </tr>
        <tr>
          <th>4</th>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
          <td>False</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    tb.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>1000.000000</td>
          <td>1000.00000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
          <td>1000.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>500.500000</td>
          <td>0.49000</td>
          <td>0.517000</td>
          <td>0.513000</td>
          <td>0.507000</td>
          <td>0.512000</td>
          <td>0.497000</td>
          <td>0.525000</td>
          <td>0.501000</td>
          <td>0.507000</td>
          <td>0.474000</td>
          <td>0.511000</td>
          <td>0.488000</td>
          <td>0.472000</td>
        </tr>
        <tr>
          <th>std</th>
          <td>288.819436</td>
          <td>0.50015</td>
          <td>0.499961</td>
          <td>0.500081</td>
          <td>0.500201</td>
          <td>0.500106</td>
          <td>0.500241</td>
          <td>0.499624</td>
          <td>0.500249</td>
          <td>0.500201</td>
          <td>0.499573</td>
          <td>0.500129</td>
          <td>0.500106</td>
          <td>0.499465</td>
        </tr>
        <tr>
          <th>min</th>
          <td>1.000000</td>
          <td>0.00000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>250.750000</td>
          <td>0.00000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>500.500000</td>
          <td>0.00000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>1.000000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>750.250000</td>
          <td>1.00000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>1000.000000</td>
          <td>1.00000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
          <td>1.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    tb['chest_pain'].value_counts()




.. parsed-literal::

    1    512
    0    488
    Name: chest_pain, dtype: int64



.. code:: ipython3

    tb['coughing_blood'].value_counts()




.. parsed-literal::

    1    517
    0    483
    Name: coughing_blood, dtype: int64



.. code:: ipython3

    tb.groupby('body feels tired').mean()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
        <tr>
          <th>body feels tired</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>505.042596</td>
          <td>0.478702</td>
          <td>0.513185</td>
          <td>0.521298</td>
          <td>0.484787</td>
          <td>0.525355</td>
          <td>0.501014</td>
          <td>0.521298</td>
          <td>0.501014</td>
          <td>0.488844</td>
          <td>0.533469</td>
          <td>0.501014</td>
          <td>0.470588</td>
        </tr>
        <tr>
          <th>1</th>
          <td>496.082840</td>
          <td>0.500986</td>
          <td>0.520710</td>
          <td>0.504931</td>
          <td>0.528600</td>
          <td>0.499014</td>
          <td>0.493097</td>
          <td>0.528600</td>
          <td>0.500986</td>
          <td>0.459566</td>
          <td>0.489152</td>
          <td>0.475345</td>
          <td>0.473373</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    tb.groupby('chest_pain').mean()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
        <tr>
          <th>chest_pain</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>509.256148</td>
          <td>0.518443</td>
          <td>0.522541</td>
          <td>0.514344</td>
          <td>0.506148</td>
          <td>0.475410</td>
          <td>0.526639</td>
          <td>0.502049</td>
          <td>0.520492</td>
          <td>0.483607</td>
          <td>0.524590</td>
          <td>0.500000</td>
          <td>0.473361</td>
        </tr>
        <tr>
          <th>1</th>
          <td>492.154297</td>
          <td>0.462891</td>
          <td>0.511719</td>
          <td>0.511719</td>
          <td>0.507812</td>
          <td>0.517578</td>
          <td>0.523438</td>
          <td>0.500000</td>
          <td>0.494141</td>
          <td>0.464844</td>
          <td>0.498047</td>
          <td>0.476562</td>
          <td>0.470703</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    tb.groupby('coughing_blood').mean()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
          <th>loss_of_appetite</th>
        </tr>
        <tr>
          <th>coughing_blood</th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>496.354037</td>
          <td>0.467909</td>
          <td>0.515528</td>
          <td>0.482402</td>
          <td>0.517598</td>
          <td>0.509317</td>
          <td>0.515528</td>
          <td>0.494824</td>
          <td>0.503106</td>
          <td>0.496894</td>
          <td>0.507246</td>
          <td>0.515528</td>
          <td>0.447205</td>
        </tr>
        <tr>
          <th>1</th>
          <td>504.373308</td>
          <td>0.510638</td>
          <td>0.510638</td>
          <td>0.529981</td>
          <td>0.506770</td>
          <td>0.485493</td>
          <td>0.533849</td>
          <td>0.506770</td>
          <td>0.510638</td>
          <td>0.452611</td>
          <td>0.514507</td>
          <td>0.462282</td>
          <td>0.495164</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    X = tb.drop("loss_of_appetite",axis=1)
    X




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>995</th>
          <td>996</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>996</th>
          <td>997</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>997</th>
          <td>998</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>998</th>
          <td>999</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>999</th>
          <td>1000</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>1000 rows × 13 columns</p>
    </div>



.. code:: ipython3

    y = tb["loss_of_appetite"]
    y




.. parsed-literal::

    0      0
    1      1
    2      1
    3      0
    4      0
          ..
    995    1
    996    0
    997    0
    998    0
    999    0
    Name: loss_of_appetite, Length: 1000, dtype: int64



Split Data (Train and Test)
===========================

.. code:: ipython3

    from sklearn.model_selection import train_test_split

.. code:: ipython3

    X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.3, random_state=42)

.. code:: ipython3

    X_train




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>541</th>
          <td>542</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>440</th>
          <td>441</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>482</th>
          <td>483</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>422</th>
          <td>423</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>778</th>
          <td>779</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>106</th>
          <td>107</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>270</th>
          <td>271</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>860</th>
          <td>861</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>435</th>
          <td>436</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>102</th>
          <td>103</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>700 rows × 13 columns</p>
    </div>



.. code:: ipython3

    X_train.shape




.. parsed-literal::

    (700, 13)



.. code:: ipython3

    type(X_train)




.. parsed-literal::

    pandas.core.frame.DataFrame



.. code:: ipython3

    X_test 




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>no</th>
          <th>fever_for_two_weeks</th>
          <th>coughing_blood</th>
          <th>sputum_mixed with blood</th>
          <th>night_sweats</th>
          <th>chest_pain</th>
          <th>backpain_in_certain_parts</th>
          <th>shortness_of_breath</th>
          <th>weight_loss</th>
          <th>body feels tired</th>
          <th>lumps_appear_around_the_armpits_and_neck</th>
          <th>cough_and_phlegm_continuously_for_two_weeks_to_four_weeks</th>
          <th>swollen_lymph_nodes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>521</th>
          <td>522</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>737</th>
          <td>738</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>740</th>
          <td>741</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>660</th>
          <td>661</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>411</th>
          <td>412</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>468</th>
          <td>469</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
        <tr>
          <th>935</th>
          <td>936</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
        </tr>
        <tr>
          <th>428</th>
          <td>429</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>7</th>
          <td>8</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
        </tr>
        <tr>
          <th>155</th>
          <td>156</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>1</td>
          <td>0</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    <p>300 rows × 13 columns</p>
    </div>



.. code:: ipython3

    X_test.shape




.. parsed-literal::

    (300, 13)



.. code:: ipython3

    y_train




.. parsed-literal::

    541    0
    440    1
    482    1
    422    1
    778    1
          ..
    106    1
    270    1
    860    0
    435    0
    102    0
    Name: loss_of_appetite, Length: 700, dtype: int64



.. code:: ipython3

    y_train.shape




.. parsed-literal::

    (700,)



.. code:: ipython3

    y_test




.. parsed-literal::

    521    1
    737    1
    740    0
    660    1
    411    1
          ..
    468    1
    935    0
    428    0
    7      0
    155    0
    Name: loss_of_appetite, Length: 300, dtype: int64



.. code:: ipython3

    y_test.shape




.. parsed-literal::

    (300,)



Create LogisticRegression Model (Fit and Predict)
=================================================

.. code:: ipython3

    from sklearn.linear_model import LogisticRegression

.. code:: ipython3

    lor = LogisticRegression()

.. code:: ipython3

    lor.fit(X_train, y_train)




.. parsed-literal::

    LogisticRegression()



.. code:: ipython3

    y_predict = lor.predict(X_test)
    y_predict




.. parsed-literal::

    array([0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0,
           1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0,
           0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0,
           1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0,
           0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
           0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0,
           1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0,
           1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0,
           0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1,
           1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0,
           0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1,
           0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0,
           1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0,
           0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1], dtype=int64)



Feature Scaling using MinMaxScaler
==================================

.. code:: ipython3

    from sklearn.preprocessing import MinMaxScaler

.. code:: ipython3

    scaler = MinMaxScaler()

.. code:: ipython3

    ss3 = scaler.fit_transform(X_train)
    ss3




.. parsed-literal::

    array([[0.54154154, 0.        , 1.        , ..., 1.        , 1.        ,
            1.        ],
           [0.44044044, 0.        , 1.        , ..., 1.        , 0.        ,
            1.        ],
           [0.48248248, 0.        , 0.        , ..., 0.        , 1.        ,
            1.        ],
           ...,
           [0.86086086, 1.        , 1.        , ..., 0.        , 0.        ,
            0.        ],
           [0.43543544, 1.        , 0.        , ..., 1.        , 0.        ,
            1.        ],
           [0.1021021 , 1.        , 1.        , ..., 1.        , 1.        ,
            0.        ]])



.. code:: ipython3

    m_ss1 = scaler.transform(X_test)
    m_ss1




.. parsed-literal::

    array([[0.52152152, 0.        , 0.        , ..., 1.        , 0.        ,
            0.        ],
           [0.73773774, 1.        , 1.        , ..., 1.        , 1.        ,
            0.        ],
           [0.74074074, 0.        , 1.        , ..., 0.        , 1.        ,
            0.        ],
           ...,
           [0.42842843, 0.        , 0.        , ..., 0.        , 0.        ,
            0.        ],
           [0.00700701, 0.        , 0.        , ..., 1.        , 0.        ,
            1.        ],
           [0.15515516, 1.        , 1.        , ..., 0.        , 1.        ,
            0.        ]])



Precision Score
===============

.. code:: ipython3

    from sklearn.metrics import precision_score 
    print(precision_score(y_test, y_predict))


.. parsed-literal::

    0.5267175572519084
    

Recall Score
============

.. code:: ipython3

    from sklearn . metrics import recall_score 
    print(recall_score(y_test, y_predict))


.. parsed-literal::

    0.5111111111111111
    

Accuracy Score
==============

.. code:: ipython3

    from sklearn.metrics import accuracy_score 
    lor_ascore = accuracy_score(y_test, y_predict)

.. code:: ipython3

    lor_ascore




.. parsed-literal::

    0.5733333333333334



Confusion Matrix
================

.. code:: ipython3

    from sklearn.metrics import confusion_matrix
    cnf_matrix = confusion_matrix(y_test, y_predict) 
    cnf_matrix




.. parsed-literal::

    array([[103,  62],
           [ 66,  69]], dtype=int64)



.. code:: ipython3

    cf_ac_score = accuracy_score(y_test, y_predict)
    cf_ac_score




.. parsed-literal::

    0.5733333333333334



TB Plot
=======

.. code:: ipython3

    tb.plot()




.. parsed-literal::

    <AxesSubplot:>




.. image:: output_53_1.png


Create Scatter Plot
===================

.. code:: ipython3

    plt.scatter(y_test, y_predict, color='red')
    plt.show()



.. image:: output_55_0.png


.. code:: ipython3

    pd.crosstab(tb.coughing_blood,tb.chest_pain).plot(kind="bar",figsize=(19,8),color=['blue','hotpink'])
    plt.show()



.. image:: output_56_0.png


.. code:: ipython3

    sns.heatmap(tb.head(), annot=True)




.. parsed-literal::

    <AxesSubplot:>




.. image:: output_57_1.png


Heatmap of Confusion Matrix
===========================

.. code:: ipython3

    sns.heatmap(pd.DataFrame(tb), cmap='gist_rainbow_r', annot=True)




.. parsed-literal::

    <AxesSubplot:>




.. image:: output_59_1.png


Heatmap of Confusion Matrix
===========================

.. code:: ipython3

    sns.heatmap(confusion_matrix(y_test,y_predict) / len(y), cmap='gist_rainbow' , annot=True)




.. parsed-literal::

    <AxesSubplot:>




.. image:: output_61_1.png


PAIRPLOT
========

.. code:: ipython3

    sns.pairplot(X)




.. parsed-literal::

    <seaborn.axisgrid.PairGrid at 0x1c5ea512a00>




.. image:: output_63_1.png


DISTPLOT
========

.. code:: ipython3

    sns.distplot(tb["swollen_lymph_nodes"], bins=5)


.. parsed-literal::

    C:\Users\berch\anaconda3\lib\site-packages\seaborn\distributions.py:2557: FutureWarning: `distplot` is a deprecated function and will be removed in a future version. Please adapt your code to use either `displot` (a figure-level function with similar flexibility) or `histplot` (an axes-level function for histograms).
      warnings.warn(msg, FutureWarning)
    



.. parsed-literal::

    <AxesSubplot:xlabel='swollen_lymph_nodes', ylabel='Density'>




.. image:: output_65_2.png


